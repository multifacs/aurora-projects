# web-projects-collection
Лабы по ТСИ
